# Unity Shakify

A lightweight Handycam camera shake plugin for Unity using the New Input System.

## How to use:
1. Import both scripts into your Unity project.
2. Ensure you have the **Input System Package** installed.
3. Right-click in your Project window and go to `Create -> Handycam Plugin -> Shakify Profile` to create your shake settings.
4. Attach the `Unity_Shakify_Manager` component to your Main Camera.
5. Assign your Input Action (e.g., Move) and your profiles in the Inspector.