using UnityEngine;

[CreateAssetMenu(fileName = "NewShakifyProfile", menuName = "Handycam Plugin/Shakify Profile")]
public class Unity_Shakify : ScriptableObject
{
    [Header("Shake Settings")]
    public float intensity = 1.0f;
    public float speed = 5.0f;

    [Header("Axis Influence")]
    public Vector2 positionInfluence = new Vector2(0.1f, 0.1f);
    public float rotationInfluence = 1.5f;

    [Header("Fade Out")]
    public bool doesFade = false;
    public float fadeSpeed = 2.0f;
}