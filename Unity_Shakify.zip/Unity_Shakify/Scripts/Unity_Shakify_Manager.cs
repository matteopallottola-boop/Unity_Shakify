using UnityEngine;
using UnityEngine.InputSystem;

public class Unity_Shakify_Manager : MonoBehaviour
{
    [Header("Input Setup (New Input System)")]
    public InputActionReference moveAction;

    [Header("Profiles")]
    public Unity_Shakify idleProfile;
    public Unity_Shakify movementProfile;

    [Header("State")]
    public bool isPluginActive = true;

    private Unity_Shakify currentProfile;
    private Vector3 initialLocalPosition;
    private Quaternion initialLocalRotation;
    private float timer;
    private float currentIntensity;

    void OnEnable()
    {
        if (moveAction != null)
        {
            moveAction.action.Enable();
        }
    }

    void OnDisable()
    {
        if (moveAction != null)
        {
            moveAction.action.Disable();
        }
    }

    void Start()
    {
        initialLocalPosition = transform.localPosition;
        initialLocalRotation = transform.localRotation;

        currentProfile = idleProfile;
        if (currentProfile != null)
        {
            currentIntensity = currentProfile.intensity;
        }
    }

    void Update()
    {
        if (!isPluginActive) return;

        UpdateProfileBasedOnInput();

        if (currentProfile == null) return;

        timer += Time.deltaTime * currentProfile.speed;

        float noiseX = Mathf.PerlinNoise(timer, 0.0f) * 2.0f - 1.0f;
        float noiseY = Mathf.PerlinNoise(0.0f, timer) * 2.0f - 1.0f;
        float noiseZ = Mathf.PerlinNoise(timer, timer) * 2.0f - 1.0f;

        Vector3 positionOffset = new Vector3(
            noiseX * currentProfile.positionInfluence.x,
            noiseY * currentProfile.positionInfluence.y,
            0
        ) * currentIntensity;

        transform.localPosition = initialLocalPosition + positionOffset;

        float rotationZ = noiseZ * currentProfile.rotationInfluence * currentIntensity;
        float rotationX = noiseY * (currentProfile.rotationInfluence * 0.5f) * currentIntensity;

        transform.localRotation = initialLocalRotation * Quaternion.Euler(rotationX, 0, rotationZ);

        if (currentProfile.doesFade && currentIntensity > 0)
        {
            currentIntensity -= Time.deltaTime * currentProfile.fadeSpeed;
            if (currentIntensity < 0) currentIntensity = 0;
        }
    }

    private void UpdateProfileBasedOnInput()
    {
        if (moveAction == null) return;

        Vector2 movementInput = moveAction.action.ReadValue<Vector2>();

        if (movementInput.magnitude > 0.1f)
        {
            if (currentProfile != movementProfile && movementProfile != null)
            {
                ChangeProfile(movementProfile);
            }
        }
        else
        {
            if (currentProfile != idleProfile && idleProfile != null)
            {
                ChangeProfile(idleProfile);
            }
        }
    }

    public void ChangeProfile(Unity_Shakify newProfile)
    {
        currentProfile = newProfile;
        if (newProfile != null)
        {
            currentIntensity = newProfile.intensity;
        }
    }

    public void TriggerTemporaryShake(Unity_Shakify profile, float initialIntensity)
    {
        currentProfile = profile;
        currentIntensity = initialIntensity;
    }
}